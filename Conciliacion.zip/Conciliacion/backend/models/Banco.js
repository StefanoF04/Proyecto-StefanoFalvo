const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");

const Banco = sequelize.define("Banco", {
  id_cuenta: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  banco: { type: DataTypes.STRING, allowNull: false },
  numero_cuenta: { type: DataTypes.STRING, allowNull: false, unique: true },
  tipo_cuenta: { type: DataTypes.STRING, allowNull: false },
  saldo: { type: DataTypes.FLOAT, allowNull: false },
  id_usuario: { type: DataTypes.INTEGER, allowNull: false },
});

module.exports = Banco;
