const sequelize = require("../config/database");
const Usuario = require("./Usuario");
const Banco = require("./Banco");

// Definir relaciones
Usuario.hasMany(Banco, { foreignKey: "id_usuario" });
Banco.belongsTo(Usuario, { foreignKey: "id_usuario" });

// Sincronizar modelos
const syncDB = async () => {
  try {
    await sequelize.sync({ alter: true });
    console.log("Base de datos sincronizada.");
  } catch (error) {
    console.error("Error al sincronizar la base de datos:", error);
  }
};

module.exports = { sequelize, syncDB, Usuario, Banco };
