const express = require("express");
const { syncDB } = require("./models");

const app = express();
app.use(express.json());

// Rutas
app.get("/", (req, res) => {
  res.send("API de Conciliación Bancaria");
});

// Iniciar el servidor
const PORT = 3000;
app.listen(PORT, async () => {
  await syncDB();
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
